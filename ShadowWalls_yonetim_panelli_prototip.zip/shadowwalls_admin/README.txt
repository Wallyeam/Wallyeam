SHADOWWALLS YÖNETİM PANELLİ PROTOTİP

Bu sürümde:
- Yeni duvar kağıdı yükleyebilirsin.
- Başlık, kategori, cihaz ve etiket girebilirsin.
- Eklediklerini düzenleyebilir/silebilirsin.
- Veriler tarayıcıda saklanır.

ÖNEMLİ:
Bu henüz internete bağlı gerçek bir yönetim sistemi değildir. Gerçek sitede herkesin görebileceği şekilde çalışması için sunucu + veritabanı + görsel depolama + güvenli admin girişi bağlanmalıdır.
